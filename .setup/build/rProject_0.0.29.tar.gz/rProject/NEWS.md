# rProject 0.0.29

## Patch

* `AIGlobal()` installs the GitHub Copilot instructions to `~/.copilot/copilot-instructions.md`, which Copilot loads in every session. `COPILOT_CUSTOM_INSTRUCTIONS_DIRS` is no longer needed.

# rProject 0.0.28

## Patch

* `ConfigFiles()` no longer takes `git_user`. It clones `repo` (default `ijapesigan/dotfiles`) anonymously over HTTPS, ignoring Git URL rewrites, so `make dotfiles` works inside containers. It stops with an error when the clone or `make` fails.

# rProject 0.0.27

## Patch

* Added the `AIGlobal()` function and the `make aiglobal` target to install global AI instructions for Claude Code, Codex, and GitHub Copilot.

# rProject 0.0.26

## Patch

* Secrets are read from the local machine (`$RPROJECT_SECRETS`, `~/.config/rproject/<project>.R`, or `~/.config/rproject/secrets.R`) in `.setup/scripts/make-project.R`. `.setup/scripts/secrets.R` is only used as a fallback, with a warning.
* `Environment()` sets the permissions of `.Renviron` to `600`.
* Added the `SecretScan()` function and the `make secretscan` target.

# rProject 0.0.25

## Patch

* Changed year from 2025 to 2026 in MIT license.

# rProject 0.0.24

## Patch

* Address `remotes::install_github()` deprecation by using `pak::pkg_install()`.

# rProject 0.0.23

## Patch

* Edits to the `Lint()` function.

# rProject 0.0.22

## Patch

* Added the `PkgProjectBioconductor()` function.

# rProject 0.0.21

## Patch

* Specific `rProject` GitHub commit can be installed via the `rproject_ver` object in `.setup/scripts/project.R`.

# rProject 0.0.20

## Patch

* Updated MIT license year to 2025.

# rProject 0.0.19

## Patch

* The `PkgProjectGitHub()` function gives priority to installing packages that contain the `@` character in their specification.
* The `PkgProjectVersion()` function installs the available package first before checking its version.

# rProject 0.0.18

## Patch

* Added `.quarto` in the `BuildIgnore()` function.

# rProject 0.0.17

## Patch

* Revised the `Lint()` function.

# rProject 0.0.16

## Patch

* Added `tests` in exclusions in the `Lint()` function.

# rProject 0.0.15

## Patch

* Added `nolint.R` in exclusions in the `Lint()` function.

# rProject 0.0.14

## Patch

* Added `lib-2000-2009-manual` in `BibLib()`.

# rProject 0.0.13

## Patch

* Added `.sif` to `BuildIgnore()`.

# rProject 0.0.12

## Patch

* Option to NOT delete `.sim` and `.sif` in `CleanProj()`.

# rProject 0.0.11

## Patch

* Install `rhub` from CRAN.

# rProject 0.0.10

## Patch

* Added `".*\\.sif$` in `BuildIgnore()`.

# rProject 0.0.9

## Patch

* Added the `LatexTikzCompile()` function and `LatexMake()` calls it before `LatexCompile()`.

# rProject 0.0.8

## Patch

* `knit::knit()` uses `envir = new.env()`.

# rProject 0.0.7

## Patch

* Exclude `R/methods.R` from linting in `Lint()`.

# rProject 0.0.6

## Patch

* Edits to `Clean()` to keep `vignettes.bib` when `push = TRUE`.

# rProject 0.0.5

## Patch

* Option to build `bib.bib` from `lib-*` repositories using `Bib()`.

# rProject 0.0.4

## Patch

* Added build tools for `Rcpp()` functions.

# rProject 0.0.3

## Patch

* Added the the function `Bib()` to generate `bib.bib` files for LateX, quarto, and vignettes.

# rProject 0.0.2

## Patch

* Added the argumnent `push` to `Clean()` for cleaning the directory in preparation for git push.

# rProject 0.0.1

## Patch

* Started version numbers.
