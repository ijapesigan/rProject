## ---- test-rProject-pkg-snapshot
lapply(
  X = 1,
  FUN = function(i,
                 text) {
    state <- .TestState(vars = "RPROJECT_SNAPSHOT")
    root <- .TestProject()
    none <- file.path(root, "none.json")
    labels <- file.path(root, "labels.json")
    writeLines(
      text = c(
        "{",
        "  \"org.opencontainers.image.created\": \"2026-10-22T16:33:24Z\"",
        "}"
      ),
      con = labels
    )
    testthat::test_that(
      paste(text, "is latest without an image, a lock, or the variable"),
      {
        Sys.unsetenv(x = "RPROJECT_SNAPSHOT")
        testthat::expect_equal(
          object = .PkgSnapshot(path = root, labels = none),
          expected = "latest"
        )
      }
    )
    testthat::test_that(
      paste(text, "takes the lock, the day before the sif, then the variable"),
      {
        writeLines(
          text = "snapshot <- \"2026-01-02\"",
          con = file.path(root, ".setup", "scripts", "rproject.lock")
        )
        testthat::expect_equal(
          object = .PkgSnapshot(path = root, labels = none),
          expected = "2026-01-02"
        )
        testthat::expect_equal(
          object = .PkgSnapshot(path = root, labels = labels),
          expected = "2026-10-21"
        )
        Sys.setenv(RPROJECT_SNAPSHOT = "2025-05-05")
        testthat::expect_equal(
          object = .PkgSnapshot(path = root, labels = labels),
          expected = "2025-05-05"
        )
        Sys.setenv(RPROJECT_SNAPSHOT = "latest")
        testthat::expect_equal(
          object = .PkgSnapshot(path = root, labels = labels),
          expected = "2026-10-21"
        )
      }
    )
    .TestRestore(state = state)
    unlink(x = dirname(path = root), recursive = TRUE)
  },
  text = "test-rProject-pkg-snapshot"
)
