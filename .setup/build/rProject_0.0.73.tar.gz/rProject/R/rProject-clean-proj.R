#' Clean Project
#'
#' Remove all files except `project.Rproj` and,
#' optionally, `.library`.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @inheritParams LibPaths
#' @param lib Logical.
#'   If `lib = TRUE`, delete `.library`.
#'   If `lib = FALSE`, `.library` is not deleted.
#' @param sim Logical.
#'   If `sim = TRUE`, delete `.sim`.
#'   If `sim = FALSE`, `.sim` is not deleted.
#' @param sif Logical.
#'   If `sif = TRUE`, delete `.sif`.
#'   If `sif = FALSE`, `.sif` is not deleted.
#' @return Called for its side effects; the value is not meaningful.
#' @examples
#' \dontrun{
#' CleanProj(path = getwd())
#' }
#' @export
CleanProj <- function(path,
                      lib = FALSE,
                      sim = FALSE,
                      sif = FALSE) {
  dirs <- list.dirs(
    path = path,
    full.names = FALSE,
    recursive = FALSE
  )
  if (!lib) {
    if (".library" %in% dirs) {
      dirs <- dirs[
        stats::complete.cases(
          gsub(
            pattern = ".library",
            replacement = NA,
            x = dirs
          )
        )
      ]
    }
  }
  if (!sim) {
    if (".sim" %in% dirs) {
      dirs <- dirs[
        stats::complete.cases(
          gsub(
            pattern = ".sim",
            replacement = NA,
            x = dirs
          )
        )
      ]
    }
  }
  if (!sif) {
    if (".sif" %in% dirs) {
      dirs <- dirs[
        stats::complete.cases(
          gsub(
            pattern = ".sif",
            replacement = NA,
            x = dirs
          )
        )
      ]
    }
  }
  dirs <- file.path(
    path,
    dirs
  )
  try(
    expr = unlink(
      x = dirs,
      recursive = TRUE,
      force = TRUE
    )
  )
  files <- list.files(
    path = path,
    all.files = TRUE,
    recursive = FALSE,
    full.names = FALSE,
    no.. = TRUE
  )
  # list.files() also returns folders, so keep the protected ones here too
  keep <- c(
    "project.Rproj",
    if (!lib) {
      ".library"
    },
    if (!sim) {
      ".sim"
    },
    if (!sif) {
      ".sif"
    }
  )
  files <- files[!(files %in% keep)]
  files <- file.path(
    path,
    files
  )
  try(
    expr = unlink(
      x = files,
      recursive = TRUE,
      force = TRUE
    )
  )
}
