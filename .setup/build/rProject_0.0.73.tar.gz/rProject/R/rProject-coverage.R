#' Code Coverage
#'
#' Runs `covr::package_coverage()` on the package. To leave files out,
#' put covr's `.covrignore` at the project root (and add it to
#' `.Rbuildignore` with `ignore` in `.setup/scripts/project.R`).
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @inheritParams LibPaths
#' @return Called for its side effects; the value is not meaningful.
#' @examples
#' \dontrun{
#' Coverage(path = getwd())
#' }
#' @export
Coverage <- function(path) {
  if (
    file.exists(
      file.path(
        path,
        "DESCRIPTION"
      )
    )
  ) {
    lib <- LibPaths(path = path)
    installed <- utils::installed.packages()
    pkg_installed <- installed[, "Package"]
    if (!("covr" %in% pkg_installed)) {
      utils::install.packages(
        pkgs = "covr",
        repos = c(REPO_NAME = PkgRepo(path = path)),
        lib = lib,
        quiet = TRUE
      )
    }
    covr::package_coverage(path = path)
  } else {
    message(
      paste(
        path,
        "is not an R package."
      )
    )
  }
}
