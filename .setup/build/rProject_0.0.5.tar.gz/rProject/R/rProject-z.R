#' Data from the Standard Normal Distribution
#'
#' @format A vector of length 100.
#' @keywords data
"z"
