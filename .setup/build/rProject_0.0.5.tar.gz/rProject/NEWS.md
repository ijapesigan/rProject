# rProject 0.0.6

## Patch

Edits to `Clean()` to keep `bib` files when `push = TRUE`.

# rProject 0.0.5

## Patch

Option to build `bib.bib` from `lib-*` repositories using `Bib()`.

# rProject 0.0.4

## Patch

Added build tools for `Rcpp()` functions.

# rProject 0.0.3

## Patch

Added the the function `Bib()` to generate `bib.bib` files for LateX, quarto, and vignettes.

# rProject 0.0.2

## Patch

Added the argumnent `push` to `Clean()` for cleaning the directory in preparation for git push.

# rProject 0.0.1

## Patch

Started version numbers.
