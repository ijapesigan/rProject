#' Data from the Standard Normal Distribution
#'
#' @docType data
#' @format A vector of length 100.
#' @keywords data
"z"
