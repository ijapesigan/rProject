# {{project}}

This project follows the house rules in your global instructions
(`~/.claude/CLAUDE.md`, `~/.codex/AGENTS.md`, `~/.copilot/copilot-instructions.md`).
This file adds only what is specific to this project.

**Read `.setup/ai/project.md` first.** It holds the project facts that the user
maintains (aims, data, notation, co-authors, open issues).

## Project

- Name: `{{project}}`
- Type: {{types}}
- Private repository: {{private_github}} (Overleaf pushes here)
- Overleaf project: {{private_overleaf}}
- Public repository: {{public_github}} (`make auto` pushes here)
- These come from `.setup/repo/` (private). O2G checks the private
  repository; PUB checks the public one.
- Image: **the user chooses it** and runs
  `apptainer exec <image> make <target>`; R is not installed on the host.
  Do not pick an image. When a command needs one, ask, or give the command
  with `<image>` for the user to fill in. `.setup/ai/project.md` may note the
  image the project usually uses.

## Folder map

| Folder | Contents |
|---|---|
{{folders}}

## Make targets

| Target | Does |
|---|---|
| `make all` | build, docs, LaTeX, pkgdown, quarto, coverage |
| `make lint` | style and lint the R code, and report Overleaf limits |
| `make sizecheck` | check Overleaf limits; run before uploading |
| `make spec TOPIC=<topic>` | start a spec for a change set |
| `make log TOPIC=<topic> SUMMARY="..."` | write the change-set log and its file list (`UPDATE=TRUE` refreshes the list) |
| `make verify RECORD=TRUE` | after the user pushes from Overleaf (O2G): verify and record the push. On Roar, run `bash .setup/scripts/verify.sh` on the host first to pull. |
| `make auto` | publish to the public repository (checks the export first) |
| `make tree` | the project's folders and what each is for; flags missing and non-standard folders |
| `make project` | settings, template files; restores `.setup/scripts/rproject.lock` (rProject, image, snapshot) |
| `make upgrade` | move to the newest rProject; the next `make auto` updates the lock. Never upgrade a package the image has: add it to the image |
{{targets}}

## Generated files: never edit by hand

`NAMESPACE`, `man/`, `README.md`, `CITATION.cff`, `LICENSE*`, `.Rbuildignore`,
`project.Rproj`, `R/RcppExports.R`, `src/RcppExports.cpp`, `*/bib.bib`,
`vignettes/*.Rmd` built from `.setup/vignettes/`, `.setup/latex/pdf/`,
`.setup/latex/figures/`, `data/*.rda`. Change their sources and run `make`.

## Size

Overleaf's GitHub sync stops above 7 MB of editable text and caps text files at
2 MB. Keep large data compressed (binary, e.g. `.Rds` or `.xz`) and never store
the same file twice. `make sizecheck` reports problems.
{{sections}}
