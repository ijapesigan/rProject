#' Check the Public Export
#'
#' Checks the working tree that `make auto` is about to publish
#' (after `clone.sh` swaps in the public `.git`):
#' `origin` is the repository in `.setup/repo/public-github.md`,
#' no private files (e.g., `.setup/ai/`, `.setup/logs/`, `AGENTS.md`),
#' no file larger than 50 MB,
#' and no tokens ([SecretScan()]) in the files that would be published.
#' `make auto` calls `Public()` before `git add`,
#' so a failed check stops the push.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @inheritParams LibPaths
#' @return Returns the files that would be published, invisibly.
#' @examples
#' \dontrun{
#' Public(path = getwd())
#' }
#' @export
Public <- function(path) {
  .PublicRemote(path = path)
  exported <- .PublicExport(root = path)
  problems <- .VerifyPublic(private = path)
  # tokens in files that stay private (e.g., gitignored) are not published
  secrets <- suppressMessages(
    expr = suppressWarnings(
      expr = SecretScan(
        path = path,
        error = FALSE
      )
    )
  )
  secrets <- secrets[secrets$file %in% exported, , drop = FALSE]
  problems <- c(
    problems,
    paste0(secrets$file, ":", secrets$line, " (", secrets$type, ")")[
      seq_len(length.out = nrow(x = secrets))
    ]
  )
  if (length(x = problems) > 0L) {
    stop(
      paste0(
        "\n\nThe public export of ",
        path,
        " is not safe. Nothing was published:\n",
        paste0("- ", problems, collapse = "\n"),
        "\n\nFix .gitignore or remove the files, then rerun make auto.\n\n"
      ),
      call. = FALSE
    )
  }
  message(
    paste0(
      "\n\nPublic export of ",
      path,
      ": ",
      length(x = exported),
      " files; no private files, no files over 50 MB, no tokens.\n\n"
    )
  )
  invisible(x = exported)
}
