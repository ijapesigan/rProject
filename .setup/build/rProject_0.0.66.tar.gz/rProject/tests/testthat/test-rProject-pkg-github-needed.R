## ---- test-rProject-pkg-github-needed
lapply(
  X = 1,
  FUN = function(i,
                 text) {
    sha <- "0123456789abcdef0123456789abcdef01234567"
    testthat::test_that(
      desc = paste(text, "installs a missing package"),
      code = {
        testthat::expect_true(object = .PkgGitHubNeeded(installed = FALSE))
      }
    )
    testthat::test_that(
      desc = paste(text, "never upgrades for a branch or tag"),
      code = {
        testthat::expect_false(object = .PkgGitHubNeeded(installed = TRUE))
        testthat::expect_false(
          object = .PkgGitHubNeeded(installed = TRUE, ref = "main", sha = sha)
        )
        testthat::expect_false(
          object = .PkgGitHubNeeded(installed = TRUE, ref = "v1.0.0")
        )
      }
    )
    testthat::test_that(
      desc = paste(text, "reinstalls only for a different commit SHA"),
      code = {
        testthat::expect_false(
          object = .PkgGitHubNeeded(installed = TRUE, ref = sha, sha = sha)
        )
        testthat::expect_false(
          object = .PkgGitHubNeeded(
            installed = TRUE,
            ref = "0123456",
            sha = sha
          )
        )
        testthat::expect_true(
          object = .PkgGitHubNeeded(
            installed = TRUE,
            ref = "fedcba9",
            sha = sha
          )
        )
        testthat::expect_true(
          object = .PkgGitHubNeeded(
            installed = TRUE,
            ref = sha,
            sha = NA_character_
          )
        )
      }
    )
  },
  text = "test-rProject-pkg-github-needed"
)
