## ---- test-rProject-lint-r-return
lapply(
  X = 1,
  FUN = function(i,
                 text) {
    testthat::skip_on_cran()
    testthat::test_that(
      desc = paste(text, "flags what the rule forbids"),
      code = {
        root <- .TestLintProject(
          files = list(
            "R/x.R" = c(
              "F <- function(x) {",
              "  if (x) {",
              "    return(1)",
              "  }",
              "  2",
              "}"
            )
          )
        )
        rows <- .LintRReturn(path = root)
        testthat::expect_true(object = any(rows$rule == "no-return"))
        unlink(x = dirname(path = root), recursive = TRUE)
      }
    )
    testthat::test_that(
      desc = paste(text, "passes what the rule allows"),
      code = {
        root <- .TestLintProject(
          files = list(
            "R/x.R" = c(
              "F <- function(x) {",
              "  if (x) {",
              "    1",
              "  } else {",
              "    2",
              "  }",
              "}"
            )
          )
        )
        rows <- .LintRReturn(path = root)
        testthat::expect_false(object = any(rows$rule == "no-return"))
        unlink(x = dirname(path = root), recursive = TRUE)
      }
    )
  },
  text = "test-rProject-lint-r-return"
)
