## ---- test-rProject-latex-log-check
lapply(
  X = 1,
  FUN = function(i,
                 text) {
    dir <- tempfile(pattern = "latexlog")
    dir.create(path = dir)
    good <- file.path(dir, "good.log")
    stub <- file.path(dir, "stub.log")
    full <- file.path(dir, "full.log")
    writeLines(
      text = "Output written on good.pdf (78 pages, 334979 bytes).",
      con = good
    )
    writeLines(
      text = c(
        "!  ==> Fatal error occurred, no output PDF file produced!",
        "Transcript written on stub.log."
      ),
      con = stub
    )
    writeLines(
      text = "! TeX capacity exceeded, sorry [main memory size=5000000].",
      con = full
    )
    testthat::test_that(
      desc = paste(text, "names the documents whose last run failed"),
      code = {
        out <- .LatexLogCheck(
          logs = c(good, stub, full, file.path(dir, "missing.log"))
        )
        testthat::expect_equal(
          object = unname(obj = out),
          expected = c(stub, full)
        )
      }
    )
    testthat::test_that(
      desc = paste(text, "is empty when every document compiled"),
      code = {
        testthat::expect_length(object = .LatexLogCheck(logs = good), n = 0)
      }
    )
    unlink(x = dir, recursive = TRUE)
  },
  text = "test-rProject-latex-log-check"
)
