## ---- test-rProject-pkg-repo
lapply(
  X = 1,
  FUN = function(i,
                 text) {
    testthat::test_that(
      desc = paste(text, "returns a Posit Package Manager URL"),
      code = {
        repo <- PkgRepo(path = tempdir())
        testthat::expect_length(object = repo, n = 1L)
        testthat::expect_match(
          object = repo,
          regexp = "^https://packagemanager\\.posit\\.co/cran/"
        )
        # the image's snapshot (a date), or latest
        testthat::expect_match(
          object = repo,
          regexp = "latest|/\\d{4}-\\d{2}-\\d{2}"
        )
      }
    )
  },
  text = "test-rProject-pkg-repo"
)
