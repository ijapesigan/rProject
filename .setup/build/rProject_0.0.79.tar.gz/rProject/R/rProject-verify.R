#' Verify an Overleaf Push
#'
#' Checks a push from Overleaf to the private GitHub repository
#' against the change-set log in `.setup/logs`.
#'
#' The checks, and when each fails:
#'
#' - **New commit:** the commit is already recorded in `index.md`
#'   (`.verify` is stale, or there was no new push). Nothing is recorded.
#' - **Listed files:** a file listed under "Files to update in Overleaf"
#'   is missing from or differs in the private repository.
#'   The list is the one of the pushed commit: the section of the log
#'   with a code block that starts with the commit's first line (the
#'   top-level lists for the log's own commit message; the lists inside a
#'   later push's `##` section). If no block matches, every list in the log
#'   is used. A push with no list of its own compares the files of its commit
#'   instead; a difference is then a warning, as a commit may hold generated
#'   files, and an empty commit warns that nothing was checked.
#' - **Deletions:** a file listed under "Delete in Overleaf"
#'   is still in the private repository, or the pushed commit deleted a
#'   file the list does not name (a listed folder covers its files).
#' - **Unlisted changes:** (warning only) other files differ
#'   between the project and the private repository
#'   (`.setup/notes/claude.txt`, the resume commands, and `.setup/todo/`,
#'   the user's to-do list, are not counted).
#' - **Commit message:** (warning only) the last commit message
#'   does not end with `Log: .setup/logs/<log>`.
#' - **Secrets:** [SecretScan()] finds a token in the private repository.
#' - **Public export:** a file that `make auto` would publish is private
#'   (e.g., `.setup/ai/`, `.setup/logs/`, `.setup/repo/`, `AGENTS.md`)
#'   or larger than 50 MB.
#' - **Repo info:** `.setup/repo/private-overleaf.md` is not an Overleaf
#'   project URL (for example, a share link, which grants access).
#'   Warning only: a file in `.setup/repo/` is missing,
#'   `private-github.md` differs from the `.verify` remote,
#'   or `public-github.md` differs from the repository in `clone.sh`.
#' - **Line length:** (package projects) a pushed `.R` file has a line over 80
#'   characters; the public CI lint fails on one.
#' - **Linked files:** (warning only) a file in `.setup/r-dependencies/<lib>/`
#'   differs from the pushed state of its library: `R/` of the `.verify`
#'   clone of the library project next to this one (`<lib>`, `devel-<lib>`,
#'   or `cran-<lib>`), else a local clone of the functions repository
#'   ([Linked()]).
#' - **Full text:** (warning only, `lib-*` projects) an entry this push adds has
#'   no full text in `.setup/notes/`, or a file there matches no entry
#'   ([LibFullTextReport()]).
#'
#' Generated files (e.g., `NAMESPACE`, `man/`),
#' local folders (e.g., `.library`),
#' and secret files are never compared.
#'
#' The private repository must be cloned on the host,
#' because SSH keys are not available in the container.
#' `.setup/scripts/verify.sh` clones or pulls it into `.verify`
#' (local only; never uploaded) and then calls `Verify()`.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @inheritParams LibPaths
#' @param private Character string.
#'   Path to a clone of the private repository at the pushed commit.
#'   By default `.verify` in the project.
#' @param log Character string.
#'   File name of the change-set log in `.setup/logs`.
#'   If `NULL`, the log named in the pushed commit message
#'   (`Log: .setup/logs/<log>`), else the newest log with a pending push
#'   in `.setup/logs/index.md`.
#' @param record Logical.
#'   If `TRUE`, write the commit and the result
#'   in the log's "Pushes" table and in `.setup/logs/index.md`,
#'   filling the pending row, or adding a row when there is none.
#' @param error Logical.
#'   If `TRUE`, stop with an error when a check fails.
#' @return Returns a data frame of checks
#'   with the columns `check`, `status`, and `detail`.
#' @examples
#' \dontrun{
#' Verify(path = getwd())
#' }
#' @export
Verify <- function(path,
                   private = file.path(path, ".verify"),
                   log = NULL,
                   record = FALSE,
                   error = TRUE) {
  if (is.null(x = log)) {
    # the log named in the commit message ("Log: .setup/logs/<log>") wins:
    # two logs may have a pending push (a deletions-only push first)
    log <- .VerifyLogMessage(private = private)
    if (!is.na(
      x = log
    ) && !file.exists(file.path(path, ".setup", "logs", log))) {
      log <- NA_character_
    }
  }
  if (is.na(x = log)) {
    log <- .VerifyLogPending(path = path)
  }
  if (is.na(x = log)) {
    stop(
      paste0(
        "\n\nNo pending push in ",
        file.path(path, ".setup", "logs", "index.md"),
        ", and the last commit message has no",
        " \"Log: .setup/logs/<log>\" line. Pass `log`.\n\n"
      ),
      call. = FALSE
    )
  }
  log_file <- file.path(
    path,
    ".setup",
    "logs",
    log
  )
  if (!file.exists(log_file)) {
    stop(
      paste0(
        "\n\n",
        log_file,
        " does not exist.\n\n"
      ),
      call. = FALSE
    )
  }
  message_body <- .VerifyGit(
    private = private,
    args = c("log", "-1", "--format=%B")
  )
  # the file list of this push (by its commit message), else every list
  listed <- .VerifyLogFiles(
    log_file = log_file,
    project = .VerifyProject(path = path),
    subject = message_body[1]
  )
  upload <- listed$file[listed$action == "upload"]
  delete <- listed$file[listed$action == "delete"]
  # a push with no list of its own: the files of the commit stand in. They
  # warn, not fail: a commit may hold generated files that are not compared
  no_list <- nrow(x = listed) == 0L
  if (no_list) {
    commit <- .VerifyCommitFiles(private = private)
    upload <- commit$file[commit$status != "D"]
    delete <- commit$file[commit$status == "D"]
  }
  # listed files
  upload_status <- vapply(
    X = upload,
    FUN = function(file) {
      .VerifyCompare(
        path = path,
        private = private,
        file = file
      )
    },
    FUN.VALUE = character(length = 1)
  )
  upload_bad <- upload_status != "match"
  # deletions: a listed file still in the private repository, and a file the
  # commit deleted that is not listed (a folder listed covers its files)
  delete_bad <- file.exists(file.path(private, delete))
  delete_extra <- character(length = 0L)
  if (!no_list) {
    commit <- .VerifyCommitFiles(private = private)
    deleted <- commit$file[commit$status == "D"]
    covered <- vapply(
      X = deleted,
      FUN = function(file) {
        any(file == delete | startsWith(x = file, prefix = paste0(delete, "/")))
      },
      FUN.VALUE = logical(length = 1)
    )
    delete_extra <- deleted[!covered]
  }
  # unlisted changes
  unlisted <- .VerifyUnlisted(
    path = path,
    private = private,
    listed = c(listed$file, upload, delete)
  )
  # commit message
  sha <- .VerifyGit(
    private = private,
    args = c("rev-parse", "--short", "HEAD")
  )
  # a commit already in index.md means a stale clone or no new push
  recorded <- .VerifyRecorded(
    path = path,
    sha = sha
  )
  log_line <- paste0("Log: .setup/logs/", log)
  message_ok <- any(trimws(x = message_body) == log_line)
  # secrets
  secrets <- suppressMessages(
    expr = suppressWarnings(
      expr = SecretScan(
        path = private,
        error = FALSE
      )
    )
  )
  # public export
  public <- .VerifyPublic(private = private)
  # where the project lives
  repo_info <- .VerifyRepoInfo(
    path = path,
    private = private
  )
  # the links to the functions repository
  linked <- .VerifyLinked(
    path = path,
    private = private
  )
  listed_status <- ifelse(
    test = any(upload_bad),
    yes = ifelse(test = no_list, yes = "warn", no = "fail"),
    no = ifelse(
      test = no_list && length(x = upload) + length(x = delete) == 0L,
      yes = "warn",
      no = "pass"
    )
  )
  listed_detail <- ifelse(
    test = any(upload_bad),
    yes = paste(
      upload[upload_bad],
      upload_status[upload_bad],
      collapse = "; "
    ),
    no = paste(length(x = upload), "files match")
  )
  if (no_list) {
    listed_detail <- ifelse(
      test = length(x = upload) + length(x = delete) == 0L,
      yes = "no list for this push and no files in the commit: nothing checked",
      no = paste0("no list for this push; the commit's files: ", listed_detail)
    )
  }
  checks <- data.frame(
    check = c(
      "New commit",
      "Listed files",
      "Deletions",
      "Unlisted changes",
      "Commit message",
      "Secrets",
      "Public export",
      "Repo info",
      "Linked files"
    ),
    status = c(
      ifelse(test = recorded, yes = "fail", no = "pass"),
      listed_status,
      ifelse(
        test = any(delete_bad) || length(x = delete_extra) > 0L,
        yes = "fail",
        no = "pass"
      ),
      ifelse(test = length(x = unlisted) > 0L, yes = "warn", no = "pass"),
      ifelse(test = message_ok, yes = "pass", no = "warn"),
      ifelse(test = nrow(x = secrets) > 0L, yes = "fail", no = "pass"),
      ifelse(test = length(x = public) > 0L, yes = "fail", no = "pass"),
      repo_info[["status"]],
      linked[["status"]]
    ),
    detail = c(
      ifelse(
        test = recorded,
        yes = paste(
          sha,
          "is already in index.md: .verify is stale or there is no new push",
          "(pull with bash .setup/scripts/verify.sh)"
        ),
        no = sha
      ),
      listed_detail,
      ifelse(
        test = any(delete_bad) || length(x = delete_extra) > 0L,
        yes = paste(
          c(
            if (any(delete_bad)) {
              paste(
                "still present:",
                paste(delete[delete_bad], collapse = "; ")
              )
            },
            if (length(x = delete_extra) > 0L) {
              paste(
                "deleted but not listed:",
                paste(delete_extra, collapse = "; ")
              )
            }
          ),
          collapse = "; "
        ),
        no = paste(length(x = delete), "files removed")
      ),
      ifelse(
        test = length(x = unlisted) > 0L,
        yes = paste(unlisted, collapse = "; "),
        no = "none"
      ),
      ifelse(
        test = message_ok,
        yes = log_line,
        no = paste("missing", log_line)
      ),
      ifelse(
        test = nrow(x = secrets) > 0L,
        yes = paste(unique(x = secrets$file), collapse = "; "),
        no = "none found"
      ),
      ifelse(
        test = length(x = public) > 0L,
        yes = paste(public, collapse = "; "),
        no = "no private or oversized files"
      ),
      repo_info[["detail"]],
      linked[["detail"]]
    ),
    stringsAsFactors = FALSE
  )
  # a lib-* project: the full text of the entries this push adds
  if (identical(x = .TemplateType(path = path), y = "lib")) {
    full_text <- .VerifyFullText(
      path = path,
      private = private
    )
    checks <- rbind(
      checks,
      data.frame(
        check = "Full text",
        status = full_text[["status"]],
        detail = full_text[["detail"]],
        stringsAsFactors = FALSE
      )
    )
  }
  # a package project: no line over 80 characters in the pushed R files
  # (the public CI lint fails on one); LINTR_ERROR_ON_LINT=false skips it
  if (
    .TemplateTypeGuess(path = path) %in% c("cran", "rProject") &&
      !identical(
        x = tolower(
          x = Sys.getenv(
            x = "LINTR_ERROR_ON_LINT",
            unset = "true"
          )
        ),
        y = "false"
      )
  ) {
    long <- .LongLines(
      path = private,
      files = upload
    )
    checks <- rbind(
      checks,
      data.frame(
        check = "Line length",
        status = ifelse(
          test = length(x = long) > 0L,
          yes = "fail",
          no = "pass"
        ),
        detail = ifelse(
          test = length(x = long) > 0L,
          yes = paste(utils::head(x = long, n = 20L), collapse = "; "),
          no = "no line over 80 characters in the pushed R files"
        ),
        stringsAsFactors = FALSE
      )
    )
  }
  failed <- checks$status == "fail"
  result <- ifelse(
    test = any(failed),
    yes = paste(
      "\u2717 Verify():",
      paste(checks$check[failed], collapse = ", "),
      "failed"
    ),
    no = paste0(
      "\u2713 Verify(): all checks pass",
      ifelse(
        test = any(checks$status == "warn"),
        yes = paste0(
          " (warnings: ",
          paste(checks$check[checks$status == "warn"], collapse = ", "),
          ")"
        ),
        no = ""
      )
    )
  )
  report <- paste0(
    "\n\nVerify ",
    log,
    " against ",
    sha,
    ":\n",
    paste0(
      "[",
      checks$status,
      "] ",
      checks$check,
      ": ",
      checks$detail,
      collapse = "\n"
    ),
    "\n",
    result,
    "\n\n"
  )
  if (record && recorded) {
    message("\n\nNot recorded: ", sha, " is already in index.md.\n\n")
  }
  if (record && !recorded) {
    .VerifyRecord(
      path = path,
      log = log,
      sha = sha,
      result = result,
      summary = c(message_body, "")[1],
      subject = c(message_body, "")[1]
    )
  }
  if (any(failed) && error) {
    stop(
      report,
      call. = FALSE
    )
  } else {
    message(report)
  }
  invisible(x = checks)
}
