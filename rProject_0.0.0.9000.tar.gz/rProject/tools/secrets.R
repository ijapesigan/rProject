#' Add environment tokens here.
#'
#' tokens <- c(
#'   KEY1 = "VALUE1",
#'   KEY2 = "VALUE2"
#' )
#'

tokens <- c(
  GITHUB_PAT = "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"
)
